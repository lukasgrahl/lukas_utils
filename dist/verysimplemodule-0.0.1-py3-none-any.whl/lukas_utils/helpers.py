def test_func(x: str):
	print(x)
	pass